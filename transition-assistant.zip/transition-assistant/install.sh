#!/bin/bash
# Installation script for Transition Assistant
# Script d'installation pour Transition Assistant

echo "=========================================="
echo "🏅 TRANSITION ASSISTANT - INSTALLATION 🏅"
echo "=========================================="
echo ""

# Detect OS
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="Linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="Mac"
elif [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    OS="Windows"
else
    OS="Unknown"
fi

echo "📍 Système détecté / OS detected: $OS"
echo ""

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 1. Check Python
echo "1️⃣ Vérification de Python / Checking Python..."
if command_exists python3; then
    PYTHON_CMD="python3"
elif command_exists python; then
    PYTHON_CMD="python"
else
    echo "❌ Python n'est pas installé / Python is not installed"
    echo "👉 Téléchargez Python sur / Download Python from: https://www.python.org/downloads/"
    exit 1
fi

PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | grep -oE '[0-9]+\.[0-9]+')
echo "✅ Python $PYTHON_VERSION trouvé / found"
echo ""

# 2. Create virtual environment
echo "2️⃣ Création de l'environnement virtuel / Creating virtual environment..."
if [ ! -d "venv" ]; then
    $PYTHON_CMD -m venv venv
    echo "✅ Environnement virtuel créé / Virtual environment created"
else
    echo "✅ Environnement virtuel existe déjà / Virtual environment already exists"
fi
echo ""

# 3. Activate virtual environment
echo "3️⃣ Activation de l'environnement / Activating environment..."
if [ "$OS" == "Windows" ]; then
    source venv/Scripts/activate 2>/dev/null || ./venv/Scripts/activate
else
    source venv/bin/activate
fi
echo "✅ Environnement activé / Environment activated"
echo ""

# 4. Upgrade pip
echo "4️⃣ Mise à jour de pip / Upgrading pip..."
$PYTHON_CMD -m pip install --upgrade pip --quiet
echo "✅ Pip mis à jour / Pip upgraded"
echo ""

# 5. Install requirements
echo "5️⃣ Installation des dépendances / Installing dependencies..."
echo "⏳ Cela peut prendre quelques minutes / This may take a few minutes..."
pip install -r requirements.txt --quiet --no-cache-dir
echo "✅ Dépendances installées / Dependencies installed"
echo ""

# 6. Check Ollama
echo "6️⃣ Vérification d'Ollama / Checking Ollama..."
if command_exists ollama; then
    echo "✅ Ollama est installé / Ollama is installed"
    
    # Check if mistral model is available
    echo "   Vérification du modèle Mistral / Checking Mistral model..."
    if ollama list 2>/dev/null | grep -q "mistral"; then
        echo "   ✅ Modèle Mistral disponible / Mistral model available"
    else
        echo "   ⚠️ Modèle Mistral non trouvé / Mistral model not found"
        echo "   👉 Installation du modèle / Installing model..."
        echo "   Exécutez / Run: ollama run mistral"
    fi
else
    echo "❌ Ollama n'est pas installé / Ollama is not installed"
    echo "👉 Téléchargez Ollama sur / Download Ollama from: https://ollama.ai"
fi
echo ""

# 7. Check credentials.json
echo "7️⃣ Vérification des credentials Google / Checking Google credentials..."
if [ -f "credentials.json" ]; then
    echo "✅ credentials.json trouvé / found"
else
    echo "⚠️ credentials.json non trouvé / not found"
    echo "👉 Suivez les instructions dans le README pour créer ce fichier"
    echo "   Follow README instructions to create this file"
fi
echo ""

# 8. Check config
echo "8️⃣ Vérification de la configuration / Checking configuration..."
if grep -q "VOTRE_FOLDER_ID_ICI" config.py; then
    echo "⚠️ Configuration non complétée / Configuration not completed"
    echo "👉 Modifiez config.py avec votre FOLDER_ID"
    echo "   Edit config.py with your FOLDER_ID"
else
    echo "✅ Configuration semble correcte / Configuration seems correct"
fi
echo ""

# 9. Create shortcuts
echo "9️⃣ Création des raccourcis / Creating shortcuts..."

# Create start script
cat > start.sh << 'EOF'
#!/bin/bash
echo "🚀 Démarrage de Transition Assistant / Starting Transition Assistant..."
echo ""

# Check if Ollama is running
if ! pgrep -x "ollama" > /dev/null; then
    echo "📌 Démarrage d'Ollama / Starting Ollama..."
    ollama serve > /dev/null 2>&1 &
    sleep 3
fi

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
fi

# Start Streamlit
echo "🌐 Ouverture de l'application / Opening application..."
echo "👉 URL: http://localhost:8501"
echo ""
streamlit run app.py
EOF

chmod +x start.sh

# Create Windows batch file
cat > start.bat << 'EOF'
@echo off
echo 🚀 Demarrage de Transition Assistant / Starting Transition Assistant...
echo.

REM Activate virtual environment
call venv\Scripts\activate.bat

REM Start Streamlit
echo 🌐 Ouverture de l'application / Opening application...
echo 👉 URL: http://localhost:8501
echo.
streamlit run app.py
pause
EOF

echo "✅ Raccourcis créés / Shortcuts created:"
echo "   - Linux/Mac: ./start.sh"
echo "   - Windows: start.bat"
echo ""

# 10. Final message
echo "=========================================="
echo "✅ INSTALLATION TERMINÉE / INSTALLATION COMPLETE"
echo "=========================================="
echo ""
echo "📋 Prochaines étapes / Next steps:"
echo ""
echo "1. Si ce n'est pas fait / If not done:"
echo "   - Installez Ollama: https://ollama.ai"
echo "   - Téléchargez le modèle / Download model: ollama run mistral"
echo ""
echo "2. Configurez Google Drive / Configure Google Drive:"
echo "   - Créez credentials.json (voir README / see README)"
echo "   - Modifiez config.py avec votre FOLDER_ID"
echo ""
echo "3. Lancez l'application / Start application:"
if [ "$OS" == "Windows" ]; then
    echo "   - Double-cliquez sur / Double-click: start.bat"
else
    echo "   - Exécutez / Run: ./start.sh"
fi
echo ""
echo "💬 Support: Consultez le README pour plus d'aide"
echo "   Check README for more help"
echo ""
echo "🏅 Bonne transition ! / Good transition! 🏅"
